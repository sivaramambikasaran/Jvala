#include"anukalana.hpp"

//	LeapFrog Single step
void Integrator::LeapFrog_Singlestep(double dt, double& t, Eigen::VectorXd& yPrev, Eigen::VectorXd& yNext) {
	Eigen::VectorXd yCurr	=	yNext;
	yNext					=	yPrev + 2.0*dt*function(t, yCurr);
	yPrev					=	yCurr;
	t+=dt;
};

//	LeapFrog Nonadaptive integrator: Stores only the final step
Eigen::VectorXd Integrator::LeapFrog_NonAdaptive() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	Eigen::VectorXd yPrev	=	yInitial;

	double mu				=	1.0/3.0;
	double lambda			=	4.0;
	std::vector<double> parameters;
	parameters.push_back(mu);
	parameters.push_back(lambda);

	RK_NonAdaptive_Coefficients(6, 1, parameters);
	RK_NonAdaptive_Driver(deltat, t, yFinal);

	for (int j=0; j<nTimeSteps-1; ++j) {
		LeapFrog_Singlestep(deltat, t, yPrev, yFinal);
	}
	return yFinal;
};

//	LeapFrog Nonadaptive integrator: Stores all the intermediate steps
std::vector<Eigen::VectorXd> Integrator::LeapFrog_NonAdaptive_All() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	Eigen::VectorXd yPrev	=	yInitial;
	std::vector<Eigen::VectorXd> yAll;
	yAll.push_back(yFinal);

	double mu				=	1.0/3.0;
	double lambda			=	4.0;
	std::vector<double> parameters;
	parameters.push_back(mu);
	parameters.push_back(lambda);

	RK_NonAdaptive_Coefficients(6, 1, parameters);
	RK_NonAdaptive_Driver(deltat, t, yFinal);
	yAll.push_back(yFinal);

	for (int j=0; j<nTimeSteps-1; ++j) {
		// std::cout << yFinal.norm() << "\n";
		LeapFrog_Singlestep(deltat, t, yPrev, yFinal);
		yAll.push_back(yFinal);
	}
	return yAll;
};
