#include"anukalana.hpp"

//	EulerImplicit Single step
void Integrator::EulerImplicit_Singlestep(double dt, double& t, Eigen::VectorXd& yNext) {
	Eigen::MatrixXd J		=	Jacobian(t, yNext);
	Eigen::MatrixXd A		=	Eigen::MatrixXd::Identity(J.rows(),J.cols())-dt*J;
	yNext+=dt*A.fullPivLu().solve(function(t,yNext));
};

//	Euler Implicit Nonadaptive integrator: Stores only the final step
Eigen::VectorXd Integrator::EulerImplicit_NonAdaptive() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;

	for (int j=0; j<nTimeSteps; ++j) {
		EulerImplicit_Singlestep(deltat, t, yFinal);
	}
	return yFinal;
};

//	Euler Implicit Nonadaptive integrator: Stores all the intermediate steps
std::vector<Eigen::VectorXd> Integrator::EulerImplicit_NonAdaptive_All() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	std::vector<Eigen::VectorXd> yAll;
	yAll.push_back(yFinal);

	for (int j=0; j<nTimeSteps; ++j) {
		EulerImplicit_Singlestep(deltat, t, yFinal);
		yAll.push_back(yFinal);
	}
	return yAll;
};
