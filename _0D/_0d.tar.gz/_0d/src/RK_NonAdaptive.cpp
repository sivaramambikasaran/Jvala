#include"anukalana.hpp"

//	Driver for all Nonadaptive RK schemes
void Integrator::RK_NonAdaptive_Driver(double dt, double& t, Eigen::VectorXd& yNext) {
	int	n		=	c.size();
	Eigen::VectorXd k[n];
	int j		=	0;
	k[j]		=	dt*function(t,yNext);
	int count	=	0;
	while (j<n-1) {
		++j;
		Eigen::VectorXd temp	=	yNext;
		for (int l=0; l<j; ++l) {
			temp+=b[count]*k[l];
			++count;
		}
		k[j]	=	dt*function(t+a[j-1]*dt,temp);
	}
	for (int j=0; j<n; ++j) {
		yNext+=c[j]*k[j];
	}
	t+=dt;
}

//	RK assign coefficients
void Integrator::RK_NonAdaptive_Coefficients(int nOrder, int method, std::vector<double> parameters) {
	//	Coefficients 'a' are incharge of the time step
	this->a.clear();
	//	Coefficients 'b' are the table entries in the Butcher tableau
	this->b.clear();
	//	Coefficients 'c' are incharge of the final function
		this->c.clear();
	if (nOrder==1) {
		this->a.push_back(0.0);
		this->c.push_back(1.0);
	}
	else if (nOrder==2) {
		double alpha	=	parameters[0];
		
		this->a.push_back(0.0);
		this->a.push_back(alpha);
		this->b.push_back(alpha);
		this->c.push_back(1-0.5/alpha);
		this->c.push_back(0.5/alpha);
	}
	else if (nOrder==3) {
		double a2	=	parameters[0];
		double a3	=	parameters[1];
		double c2	=	(3.0*a3-2.0)/(6.0*a2*(a3-a2));
		double c3	=	(3.0*a2-2.0)/(6.0*a3*(a2-a3));
		double c1	=	1.0-c2-c3;
		double b32	=	1.0/6.0/c3/a2;
		double b21	=	a2;
		double b31	=	a3-b32;
		
		this->a.push_back(0.0);
		this->a.push_back(a2);
		this->a.push_back(a3);
		this->b.push_back(b21);
		this->b.push_back(b31);
		this->b.push_back(b32);
		this->c.push_back(c1);
		this->c.push_back(c2);
		this->c.push_back(c3);
	}
	else if (nOrder==4) {
		double a2	=	parameters[0];
		double a3	=	parameters[1];
		double a4	=	1.0;

		if (a2==a3) {
				this->a.push_back(0.0);
				this->a.push_back(0.5);
				this->a.push_back(0.5);
				this->a.push_back(1.0);
				this->b.push_back(0.5);
				this->b.push_back(0.0);
				this->b.push_back(0.5);
				this->b.push_back(0.0);
				this->b.push_back(0.0);
				this->b.push_back(1.0);
				this->c.push_back(1.0/6.0);
				this->c.push_back(1.0/3.0);
				this->c.push_back(1.0/3.0);
				this->c.push_back(1.0/6.0);
		}
		else {
			Eigen::MatrixXd C(4,4);
			C << 1.0, 1.0, 1.0, 1.0,
			0.0, a2, a3, 1.0,
			0.0, a2*a2, a3*a3, 1.0,
			0.0, a2*a2*a2, a3*a3*a3, 1.0;
			Eigen::VectorXd rc(4);
			rc << 1.0, 0.5, 1.0/3.0, 0.25;
			Eigen::VectorXd cv	=	C.fullPivHouseholderQr().solve(rc);

			Eigen::MatrixXd B(3,3);
			B << cv(2)*a2, cv(3)*a2, cv(3)*a3,
			cv(2)*a3*a2, cv(3)*a4*a2, cv(3)*a4*a3,
			cv(2)*a2*a2, cv(3)*a2*a2, cv(3)*a3*a3;
			Eigen::VectorXd rb(3);
			rb	<<	1.0/6.0, 0.125, 0.25/3.0;

			Eigen::VectorXd bv	=	B.fullPivHouseholderQr().solve(rb);

			this->a.push_back(0.0);
			this->a.push_back(a2);
			this->a.push_back(a3);
			this->a.push_back(a4);
			this->b.push_back(a2);
			this->b.push_back(a3-bv(0));
			this->b.push_back(bv(0));
			this->b.push_back(a4-(bv(1)+bv(2)));
			this->b.push_back(bv(1));
			this->b.push_back(bv(2));
			this->c.push_back(cv(0));
			this->c.push_back(cv(1));
			this->c.push_back(cv(2));
			this->c.push_back(cv(3));
		}

		// std::cout << a[0] << "\t" << a[1] << "\t" << a[2] << "\t" << a[3] << "\n";
		// std::cout << b[0] << "\t" << b[1] << "\t" << b[2] << "\t" << b[3] << "\t" << b[4] << "\t" << b[5] << "\n";
		// std::cout << c[0] << "\t" << c[1] << "\t" << c[2] << "\t" << c[3] << "\n";
	}
	//	First RK method of order 5
	else if (nOrder==5) {
		if (method == 1) {
			this->a.push_back(0.0);
			this->a.push_back(0.5);
			this->a.push_back(0.25);
			this->a.push_back(0.5);
			this->a.push_back(0.75);
			this->a.push_back(1.0);

			this->b.push_back(0.5);
			this->b.push_back(0.1875);
			this->b.push_back(0.0625);
			this->b.push_back(0.0);
			this->b.push_back(0.0);
			this->b.push_back(0.5);
			this->b.push_back(0.0);
			this->b.push_back(-0.1875);
			this->b.push_back(0.375);
			this->b.push_back(0.5625);
			this->b.push_back(1.0/7.0);
			this->b.push_back(4.0/7.0);
			this->b.push_back(6.0/7.0);
			this->b.push_back(-12.0/7.0);
			this->b.push_back(8.0/7.0);

			this->c.push_back(0.7/9.0);
			this->c.push_back(0.0);
			this->c.push_back(3.2/9.0);
			this->c.push_back(1.2/9.0);
			this->c.push_back(3.2/9.0);
			this->c.push_back(0.7/9.0);
		}
		else if (method == 2) {
			this->a.push_back(0.0);
			this->a.push_back(0.25);
			this->a.push_back(0.25);
			this->a.push_back(0.5);
			this->a.push_back(0.75);
			this->a.push_back(1.0);

			this->b.push_back(0.25);
			this->b.push_back(0.125);
			this->b.push_back(0.125);
			this->b.push_back(0.0);
			this->b.push_back(0.0);
			this->b.push_back(0.5);
			this->b.push_back(0.1875);
			this->b.push_back(-0.375);
			this->b.push_back(0.375);
			this->b.push_back(0.5625);
			this->b.push_back(-3.0/7.0);
			this->b.push_back(8.0/7.0);
			this->b.push_back(6.0/7.0);
			this->b.push_back(-12.0/7.0);
			this->b.push_back(8.0/7.0);

			this->c.push_back(0.7/9.0);
			this->c.push_back(0.0);
			this->c.push_back(3.2/9.0);
			this->c.push_back(1.2/9.0);
			this->c.push_back(3.2/9.0);
			this->c.push_back(0.7/9.0);
		}
	}
	else if (nOrder==6) {
		double mu		=	parameters[0];
		double lambda	=	parameters[1];

		a.push_back(0.0);
		a.push_back(mu);
		a.push_back(2.0/3.0);
		a.push_back(1.0/3.0);
		a.push_back(0.5);
		a.push_back(0.5);
		a.push_back(1.0);

		b.push_back(mu);
		b.push_back(2.0/3.0-2.0/9.0/mu);
		b.push_back(2.0/9.0/mu);
		b.push_back(3.75/9.0-1.0/9.0/mu);
		b.push_back(1.0/9.0/mu);
		b.push_back(-0.75/9.0);
		b.push_back(1.0625-0.375/mu);
		b.push_back(0.375/mu);
		b.push_back(-0.1875);
		b.push_back(-0.375);
		b.push_back(1.0625-0.375/mu+0.25/lambda);
		b.push_back(0.375/mu);
		b.push_back(-(0.1875+0.75/lambda));
		b.push_back(-(0.375+1.5/lambda));
		b.push_back(2.0/lambda);
		b.push_back(-6.75/11.0+3.0/11.0/mu);
		b.push_back(-3.0/11.0/mu);
		b.push_back(15.75/11.0);
		b.push_back(18.0/11.0);
		b.push_back((4.0*lambda-16.0)/11.0);
		b.push_back(-4.0*lambda/11.0);

		c.push_back(0.825/9.0);
		c.push_back(0.0);
		c.push_back(0.675);
		c.push_back(0.675);
		c.push_back(0.2*(lambda-8.0)/3.0);
		c.push_back(-0.2*lambda/3.0);
		c.push_back(0.825/9.0);
	}
}

//	RK NonAdaptive integrator: Stores only the final step
Eigen::VectorXd Integrator::RK_NonAdaptive(int nOrder, int method, std::vector<double> parameters) {
	RK_NonAdaptive_Coefficients(nOrder, method, parameters);
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;

	for (int j=0; j<nTimeSteps; ++j) {
		RK_NonAdaptive_Driver(deltat, t, yFinal);
	}
	return yFinal;
};

//	RK NonAdaptive integrator: Stores all the intermediate steps
std::vector<Eigen::VectorXd> Integrator::RK_NonAdaptive_All(int nOrder, int method, std::vector<double> parameters) {
	RK_NonAdaptive_Coefficients(nOrder, method, parameters);
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	std::vector<Eigen::VectorXd> yAll;
	yAll.push_back(yFinal);

	for (int j=0; j<nTimeSteps; ++j) {
		RK_NonAdaptive_Driver(deltat, t, yFinal);
		yAll.push_back(yFinal);
	}
	return yAll;
};
