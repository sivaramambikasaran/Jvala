#include<vector>
#include<iostream>
#include<string>
#include<fstream>
#include<Eigen/Dense>
#include<cmath>

#include<regex>
int N, L;
std::vector<std::string> Species;
std::vector<std::vector<double> > Press_coefs;

int get_Index(std::string s)
{
	std::string temp;
	for(unsigned i=0;i<N;++i)
	{
		if(s.compare(Species[i])==0)
			return i;
	}
	return -1;
}

int main()
{
	std::ifstream fin;
	fin.open("33_species_heptane.mech",std::ios::in);
	std::string s;


	//regexes
	std::regex Spc("[A-Za-z][A-Za-z0-9\\-]*");
	std::regex coef("[0-9]*");
	std::regex AnE1("\\s*[0-9]+\\.[0-9]+([e|E]\\+[0-9]+)?");
	while(fin)
	{
		std::getline(fin,s);
		if(s.std::string::length()==0) continue;

		std::size_t start = 0;
    		std::size_t end = s.std::string::find_first_of(" \t\n",start);
		std::string token = s.substr(start, end - start);

		if(isdigit(token[0])||token[0]=='C')
		{
			unsigned i=0;
			if(!isdigit(token[0])) i++;
			std::string temp=token.substr(i,1);
			i++;
			for(;i<token.length();++i)
			{
				if(isdigit(token[i])) 
					temp+=token[i];
			}
			L=std::atof(temp.c_str());
			start = end + 1;
			end = s.std::string::find_first_of(" \t\n",start);
		}
		else 
			continue;
    		while (end != std::string::npos)
    		{
			std::string token = s.substr(start, end - start);
			start = end + 1;
			end = s.std::string::find_first_of(" \t\n",start);
			if(std::regex_match(token,Spc))
			{
				if(get_Index(token)==-1||N==0)
				{
					Species.push_back(token);
					N++;
				}
			}
			else if(std::regex_match(token,coef)||token=="->"||token=="+") 
				continue;
			else if(token=="{")
				break;

    		}
		
		
//   		std::cout << s.substr(start, end);
//		std::string token = s.substr(0, s.find(delimiter));
	}
std::cout<<L<<"\n"<<N<<"\n";

	return 0;
}
