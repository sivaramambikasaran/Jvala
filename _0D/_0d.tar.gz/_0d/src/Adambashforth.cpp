#include"anukalana.hpp"

//	Adamsbashforth Single step
void Integrator::Adamsbashforth_Singlestep(double dt, double& t, Eigen::VectorXd& yPrev, Eigen::VectorXd& yNext) {
	Eigen::VectorXd yCurr	=	yNext;
	yNext+=dt*(1.5*function(t,yCurr)-0.5*function(t-dt,yPrev));
	yPrev					=	yCurr;
	t+=dt;
};

//	Adamsbashforth Nonadaptive integrator: Stores only the final step
Eigen::VectorXd Integrator::AdamsBashforth_NonAdaptive() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	Eigen::VectorXd yPrev	=	yInitial;

	double mu				=	1.0/3.0;
	double lambda			=	4.0;
	std::vector<double> parameters;
	parameters.push_back(mu);
	parameters.push_back(lambda);

	RK_NonAdaptive_Coefficients(6, 1, parameters);
	RK_NonAdaptive_Driver(deltat, t, yFinal);

	for (int j=0; j<nTimeSteps-1; ++j) {
		Adamsbashforth_Singlestep(deltat, t, yPrev, yFinal);
	}
	return yFinal;
};

//	Adamsbashforth Adaptive integrator: Stores all the intermediate steps
std::vector<Eigen::VectorXd> Integrator::AdamsBashforth_NonAdaptive_All() {
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	Eigen::VectorXd yPrev	=	yInitial;
	std::vector<Eigen::VectorXd> yAll;
	yAll.push_back(yFinal);

	double mu				=	1.0/3.0;
	double lambda			=	4.0;
	std::vector<double> parameters;
	parameters.push_back(mu);
	parameters.push_back(lambda);

	RK_NonAdaptive_Coefficients(6, 1, parameters);
	RK_NonAdaptive_Driver(deltat, t, yFinal);
	yAll.push_back(yFinal);

	for (int j=0; j<nTimeSteps-1; ++j) {
		Adamsbashforth_Singlestep(deltat, t, yPrev, yFinal);
		yAll.push_back(yFinal);
	}
	return yAll;
};
