#include"anukalana.hpp"

//	Driver for all Nonadaptive RK schemes
void Integrator::RK_Adaptive_Driver(double dt, double& t, Eigen::VectorXd& yNext, Eigen::VectorXd& error) {
	int	n		=	c.size();
	Eigen::VectorXd k[n];
	int j		=	0;
	k[j]		=	dt*function(t,yNext);
	int count	=	0;
	while (j<n-1) {
		++j;
		Eigen::VectorXd temp	=	yNext;
		for (int l=0; l<j; ++l) {
			temp+=b[count]*k[l];
			++count;
		}
		k[j]	=	dt*function(t+a[j-1]*dt,temp);
	}
	error	=	Eigen::VectorXd::Zero(yNext.size());
	for (int j=0; j<n; ++j) {
		yNext+=c[j]*k[j];
		error+=dt*(c[j]-cstar[j])*k[j];
	}
	t+=dt;
};

//	RK assign coefficients
void Integrator::RK_Adaptive_Coefficients(int nOrder, int method, std::vector<double> parameters) {
	//	Coefficients 'a' are incharge of the time step
	this->a.clear();
	//	Coefficients 'b' are the table entries in the Butcher tableau
	this->b.clear();
	//	Coefficients 'c' are incharge of the final function
	this->c.clear();
	if (nOrder==2) {
		//	Heun–Euler
		this->a.push_back(0.0);
		this->a.push_back(1.0);

		this->b.push_back(1.0);

		this->c.push_back(0.5);
		this->c.push_back(0.5);

		this->cstar.push_back(1.0);
		this->cstar.push_back(0.0);
	}
	else if (nOrder==3) {
		//	Bogacki–Shampine
		this->a.push_back(0.0);
		this->a.push_back(0.5);
		this->a.push_back(0.75);
		this->a.push_back(1.0);

		this->b.push_back(0.5);
		this->b.push_back(0);
		this->b.push_back(0.75);
		this->b.push_back(2.0/9.0);
		this->b.push_back(1.0/3.0);
		this->b.push_back(4.0/9.0);

		this->c.push_back(2.0/9.0);
		this->c.push_back(1.0/3.0);
		this->c.push_back(4.0/9.0);
		this->c.push_back(0.0);

		this->cstar.push_back(0.875/3.0);
		this->cstar.push_back(0.25);
		this->cstar.push_back(1.0/3.0);
		this->cstar.push_back(0.125);
	}
	else if (nOrder==5) {
		if (method==1) {
			this->a.push_back(0.0);
			this->a.push_back(0.25);
			this->a.push_back(0.375);
			this->a.push_back(12.0/13.0);
			this->a.push_back(1.0);
			this->a.push_back(0.5);

			this->b.push_back(0.25);
			this->b.push_back(0.09375);
			this->b.push_back(0.28125);
			this->b.push_back(1932.0/2197.0);
			this->b.push_back(-7200.0/2197.0);
			this->b.push_back(7296.0/2197.0);
			this->b.push_back(439.0/216.0);
			this->b.push_back(-8.0);
			this->b.push_back(3680.0/513.0);
			this->b.push_back(-845.0/4104.0);
			this->b.push_back(-8.0/27.0);
			this->b.push_back(2.0);
			this->b.push_back(-3544.0/2565.0);
			this->b.push_back(1859.0/4104.0);
			this->b.push_back(-11.0/40.0);

			this->c.push_back(16.0/135.0);
			this->c.push_back(0.0);
			this->c.push_back(6656.0/12825.0);
			this->c.push_back(28561.0/56430.0);
			this->c.push_back(-9.0/50.0);
			this->c.push_back(2.0/55.0);

			this->cstar.push_back(25.0/216.0);
			this->cstar.push_back(0.0);
			this->cstar.push_back(1408.0/2565.0);
			this->cstar.push_back(2197.0/4104.0);
			this->cstar.push_back(-0.2);
			this->cstar.push_back(0.0);
		}
		else if (method==2) {
		this->a.push_back(0.0);
		this->a.push_back(0.2);
		this->a.push_back(0.3);
		this->a.push_back(0.6);
		this->a.push_back(1.0);
		this->a.push_back(0.875);

		this->b.push_back(0.2);
		this->b.push_back(0.075);
		this->b.push_back(0.225);
		this->b.push_back(0.3);
		this->b.push_back(-0.9);
		this->b.push_back(1.2);
		this->b.push_back(-11.0/54.0);
		this->b.push_back(2.5);
		this->b.push_back(-70.0/27.0);
		this->b.push_back(35.0/27.0);
		this->b.push_back(1631.0/55296.0);
		this->b.push_back(175.0/512.0);
		this->b.push_back(575.0/13824.0);
		this->b.push_back(44275.0/110592.0);
		this->b.push_back(253.0/4096.0);

		this->c.push_back(37.0/378.0);
		this->c.push_back(0.0);
		this->c.push_back(250.0/621.0);
		this->c.push_back(125.0/594.0);
		this->c.push_back(0.0);
		this->c.push_back(512.0/1771.0);

		this->cstar.push_back(2825.0/27648.0);
		this->cstar.push_back(0.0);
		this->cstar.push_back(18575.0/48384.0);
		this->cstar.push_back(13525.0/55296.0);
		this->cstar.push_back(277.0/14336.0);
		this->cstar.push_back(0.25);
		}
	}
}

//	RK Adaptive integrator: Stores only the final step
Eigen::VectorXd Integrator::RK_Adaptive(int nOrder, int method, std::vector<double> parameters, double tolerance) {
	RK_Adaptive_Coefficients(nOrder, method, parameters);
	double t				=	tInit;
	Eigen::VectorXd yFinal	=	yInitial;
	Eigen::VectorXd error;
	double dt;
	double exponent		=	1.0/nOrder;

	while (t<tFinal) {
		Eigen::VectorXd yCurr	=	yFinal;
		double currentTime		=	t;
		dt						=	std::min(tFinal-t,deltat);
		RK_Adaptive_Driver(dt, t, yFinal, error);
		while (error.cwiseAbs().maxCoeff()>tolerance) {
			yFinal	=	yCurr;
			t		=	currentTime;
			dt		=	std::min(0.95*dt*pow(tolerance/error.cwiseAbs().maxCoeff(),exponent),tFinal-t);
			RK_Adaptive_Driver(dt, t, yFinal, error);
		}
	}
	return yFinal;
};

//	RK Adaptive integrator: Stores all the intermediate steps
std::vector<Eigen::VectorXd> Integrator::RK_Adaptive_All(int nOrder, int method, std::vector<double> parameters, double tolerance, std::vector<double>& timesteps) {
	RK_Adaptive_Coefficients(nOrder, method, parameters);
	double t				=	tInit;
	timesteps.push_back(t);
	Eigen::VectorXd yFinal	=	yInitial;
	std::vector<Eigen::VectorXd> yAll;
	yAll.push_back(yFinal);
	Eigen::VectorXd error;
	double dt;
	double exponent		=	1.0/nOrder;

	while (t<tFinal) {
		Eigen::VectorXd yCurr	=	yFinal;
		double currentTime		=	t;
		dt						=	std::min(tFinal-t,deltat);
		RK_Adaptive_Driver(dt, t, yFinal, error);
		while (error.cwiseAbs().maxCoeff()>tolerance) {
			yFinal	=	yCurr;
			t		=	currentTime;
			dt		=	std::min(0.95*dt*pow(tolerance/error.cwiseAbs().maxCoeff(),exponent),tFinal-t);
			RK_Adaptive_Driver(dt, t, yFinal, error);
		}
		yAll.push_back(yFinal);
		timesteps.push_back(t);
	}
	return yAll;
};
