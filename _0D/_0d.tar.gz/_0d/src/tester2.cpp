#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<Eigen/Dense>
#include<cmath>
#include<regex>

//#include"FUNCTION1.HPP"
std::vector<std::string> Species,Atoms;
std::vector<std::vector<double> > Press_coefs;
std::vector<std::vector<unsigned> > M_index;
Eigen::MatrixXd reactant_coefs,product_coefs,Mxx;
Eigen::VectorXd MW,Af,Eaf,nf,Ar,Ear,nr;
int L=0;
int N=0;
int P=0;
int A=0;
int get_Index(std::string s,std::vector<std::string > Sp)
{
	for(int i=0;i<Sp.size();++i)
	{
		if(s.compare(Sp[i])==0)
			return i;
	}
	return -1;
}

void removeColumn(Eigen::MatrixXd& matrix, unsigned int colToRemove)
{
    unsigned int numRows = matrix.rows();
    unsigned int numCols = matrix.cols()-1;

    if( colToRemove < numCols )
        matrix.block(0,colToRemove,numRows,numCols-colToRemove) = matrix.block(0,colToRemove+1,numRows,numCols-colToRemove);

    matrix.conservativeResize(numRows,numCols);
}

void thirdbodies()
{
std::cout<<"in thirdbodies\n";
	//getting indices of rxns with third bodies..+ getting indices of Ms in Species
	std::vector<unsigned> rxni;
	std::regex tbody("M[0-9]+");
std::cout<<"M_index\n";
	for(unsigned i=0;i<N;++i)
	{
		if(std::regex_match(Species[i],tbody))
		{
std::cout<<Species[i]<<"\n";
			for(unsigned j=0;j<L;++j)
			{
				if(reactant_coefs(j,i)!=0)
					{rxni.push_back(j);std::cout<<"react"<<reactant_coefs(j,i)<<"\t";std::cout<<j<<"\t";}

			}
			M_index.push_back(rxni);
	//removing Ms from matrices
			Species.erase(Species.begin()+i);
			removeColumn(reactant_coefs,i);
			removeColumn(product_coefs,i);
			N--;i--;
std::cout<<"\n";
		}
	}
std::cout<<"okay\n";

	//initialising Mxx and getting values from file
	Mxx.resize(M_index.size(),N); 
	Mxx=Eigen::MatrixXd::Zero(M_index.size(),N); 

	std::ifstream fin;
	fin.open("33_species_heptane.mech",std::ios::in);
	std::regex Spc("[A-Z][A-Za-z0-9\\-]*");
	std::regex coef("[0-9\\.]*");
	std::regex Mspc("\\[[A-Z][A-Za-z0-9\\-]*\\]");
	std::regex Mline("[Let M[0-9]+[ A-Za-z0-9\\+=\\.\\[\\]]+");
	std::size_t start,end,old;
	std::string token,s;
	int mk,Spi;

	while(fin)
	{

		std::getline(fin,s);
		if(s.std::string::length()==0) continue;
		
		Spi=mk=0;
//!! Ms appear in the same order as in rxns
//Let M1 =  + 1.9 [CO] + 12 [H2O] + 2.5 [H2] + 3.8 [CO2] + 1.0 [OTHER].
//		if(std::regex_match(s,Mline))
		if(s.std::string::substr(0,5)=="Let M")
		{
std::cout<<"in mline\n";
			old=start=0;
			end = s.std::string::find_first_of(" \t\n",start);
			while(end<s.length())
    			{
				old=start;
				start = end + 1;
				end = s.std::string::find_first_of(" \t\n",start);
				token = s.substr(start, end - start);
				if(end==std::string::npos)
				{
					end=s.length();
					token = s.substr(start, end - start-1);
				}
				if(std::regex_match(token,Mspc))
				{
					token=token.std::string::substr(1,end-start-2);
					Spi=get_Index(token,Species);
std::cout<<token<<"\t"<<Spi<<"\n";
					if(std::regex_match(token,Spc)&&Spi!=-1)
					{
						std::string prev=s.std::string::substr(old,start-old-1);
						if(std::regex_match(prev,coef))
						{
							Mxx(mk,Spi)=std::atof(prev.c_str());
						}
						else
							Mxx(mk,Spi)=1;
					}
				}
				else 
					continue;
    			}
			mk++;
std::cout<<mk<<"\t";
for(unsigned i=0;i<N;++i)
std::cout<<Mxx(mk-1,i)<<"\t";
std::cout<<"\n";
		}
	}
}

int main()
{
//	std::string s="1b: H2 + M1 -> 2 H + M1	{ a = 4.577e+19 n = -1.400 E = 436.810 }";
//	std::string s="C90f: C7H14OOH3-5-C7H15O2 + O2 -> C7H14OOH3-5O2-C7H15O4	{ a = 4.449e+14 n = -0.920 E = -0.544 }";
	std::ifstream fin;
	fin.open("33_species_heptane.mech",std::ios::in);
	std::regex Spc("[A-Z][A-Za-z0-9\\-]*");
	std::regex coef("[0-9]\\.*");
	std::regex line("[L|l]et");
	std::regex Mspc("\\[[A-Za-z][A-Za-z0-9\\-]*\\]");
	std::size_t start,end ;
	std::string token;

	while(fin)
	{
		std::string s;
		std::getline(fin,s);
		if(s.std::string::length()==0) continue;

		start = 0;
    		end = s.std::string::find_first_of(" \t\n",start);
		token = s.substr(start, end - start);
		if(std::regex_match(token,line))
		{
			start = end + 1;
			end = s.std::string::find_first_of(" \t\n",start);
			std::string token = s.substr(start, end - start);
			if(token=="allowed")
			//get allowed atoms 
			{
				start=s.std::string::find("be");
				end = s.std::string::find_first_of(" \t\n",start);
				do
				{
					start=end+1;
					while(s[start]==' ')
					{
							start=start+1;
					}
					end = s.std::string::find_first_of(" \t\n",start);
					if(end==std::string::npos)
						end=s.length();
					std::string token = s.substr(start, end - start-1);
					for (auto & c: token) c = toupper(c);
std::cout<<token<<"\n";
					Atoms.push_back(token);
					A++;

				}while(end<s.length());
			}
			else if(token=="additional")
			{
				start=s.std::string::find("be");
				end = s.std::string::find_first_of(" \t\n",start);
				std::string token = s.substr(start, end - start-1);
std::cout<<token<<"\n";

				do
				{
					start=end+1;
					while(s[start]==' ')
					{
							start=start+1;
					}
					end = s.std::string::find_first_of(" \t\n",start);
					if(end==std::string::npos)
						end=s.length();
					std::string token = s.substr(start, end - start-1);
std::cout<<token<<"\n";
					Species.push_back(token);
					N++;

				}while(end<s.length());
			}

			else if(token[0]=='M')
			{
std::cout<<"in M\n";
				int lch=0;
				while (lch!=1)
    				{
					std::string token = s.substr(start, end - start);
					start = end + 1;
					end = s.std::string::find_first_of(" \t\n",start);
					if(end==std::string::npos)
					{
						lch=1;
						end=s.length()-1;
					}
					if(std::regex_match(token,Mspc))
					{
						token=token.std::string::substr(1,end-start-1);
						if(get_Index(token,Species)==-1||N==0)
						{
							Species.push_back(token);
							N++;
						}
					}
					else if(std::regex_match(token,coef)||token=="="||token=="+") 
						continue;
    				}
				
			}
			continue;
		}

		if(isdigit(token[0])||token[0]=='C')
		{
			unsigned i=0;
			if(!isdigit(token[0])) i++;
			std::string temp=token.substr(i,1);
			i++;
			for(;i<token.length();++i)
			{
				if(isdigit(token[i])) 
					{temp+=token[i];}
			}
			L=std::atof(temp.c_str());
		}
		else 
			continue;

		while (end != std::string::npos)
    		{
			start = end +1;
			end = s.std::string::find_first_of(" \t\n",start);
			std::string token = s.substr(start, end - start);
			if(std::regex_match(token,Spc))
			{ 
				if(get_Index(token,Species)==-1||N==0)
				{
					Species.push_back(token);
					N++;
				}
			}
			else if(std::regex_match(token,coef)||token=="->"||token=="+") 
				{continue;}
			else if(token=="{")
				{break;}
    		}
	}
	std::cout<<"L="<<L<<"\nN="<<N<<"\n"<<"A="<<A<<"\n";
	for(int l=0;l<N;++l)
	std::cout<<Species[l]<<"\t";
	std::cout<<"\n";
	for(int l=0;l<A;++l)
	std::cout<<Atoms[l]<<"\t";
	std::cout<<"\n";
	fin.close();

//===============================================2nd reading of file============================================
	reactant_coefs.resize(L,N);
	product_coefs.resize(L,N);
	Af.resize(L);
	Eaf.resize(L);
	nf.resize(L);
	Ar.resize(L);
	Ear.resize(L);
	nr.resize(L);
	reactant_coefs=Eigen::MatrixXd::Zero(L,N);
	product_coefs=Eigen::MatrixXd::Zero(L,N);
	Af=Eigen::VectorXd::Zero(L);
	Eaf=Eigen::VectorXd::Zero(L);
	nf=Eigen::VectorXd::Zero(L);
	Ar=Eigen::VectorXd::Zero(L);
	Ear=Eigen::VectorXd::Zero(L);
	nr=Eigen::VectorXd::Zero(L);

//	std::ifstream fin;
	fin.open("33_species_heptane.mech",std::ios::in);
	fin.clear();
	fin.seekg(0,std::ios::beg);

//to get rxn num and f or b
	while(fin)
	{
		std::string s;
		std::getline(fin,s);
		if(s.std::string::length()==0) continue;

		start = 0;
		std::size_t old=0;
    		end = s.std::string::find_first_of(" \t\n",start);
		token = s.substr(start, end - start);
		int k=0;
		char check=' ';

		if(isdigit(token[0])||token[0]=='C')
		{
			unsigned i=0;
			if(!isdigit(token[0])) i++;
			std::string temp=token.substr(i,1);
			i++;
			for(;i<token.length();++i)
			{
				if(isdigit(token[i])) 
					{temp+=token[i];}
				else 
					break;
			}
			check=token[i];
			k=std::atof(temp.c_str());
		}
		else
			continue;

//to get reactant coef matrix
		if(check!='b')
		{
   		while (end != std::string::npos)
    		{
			old=start;
			start = end + 1;
			end = s.std::string::find_first_of(" \t\n",start);
			token = s.substr(start, end - start);
			if(token=="->") break;
			int Spi;
			Spi=get_Index(token,Species);
			if(std::regex_match(token,Spc))
			{
				std::string prev=s.std::string::substr(old,start-old-1);
				if(std::regex_match(prev,coef))
				{
					reactant_coefs(k-1,Spi)=std::atof(prev.c_str());
				}
				else
					{reactant_coefs(k-1,Spi)=1;}
			}
			else if(std::regex_match(token,coef)||token=="+") 
				continue;
    		}
std::cout<<"for:"<<k<<check<<"\n";
for(int l=0;l<N;l++)
std::cout<<reactant_coefs(k-1,l)<<"\t";
std::cout<<"\n";

//to get product coef matrix
		while (end != std::string::npos)
    		{
			old=start;
			start = end + 1;
			end = s.std::string::find_first_of(" \t\n",start);
			token = s.substr(start, end - start);
			if(token=="{") break;
			int Spi;
			Spi=get_Index(token,Species);
			if(std::regex_match(token,Spc))
			{
				std::string prev=s.std::string::substr(old,start-old-1);
				if(std::regex_match(prev,coef))
				{
					product_coefs(k-1,Spi)=std::atof(prev.c_str());
				}
				else
					product_coefs(k-1,Spi)=1;
			}
			else if(std::regex_match(token,coef)||token=="+") 
				continue;
    		}
for(int l=0;l<N;l++)
std::cout<<product_coefs(k-1,l)<<"\t";
std::cout<<"\n";
		}
		else if(check=='b')
		{
			end =s.std::string::find("=",0);
std::cout<<"Back rxn\n";
		}
//to get a,n Ea for forward and backward rxns
		start =s.std::string::find_first_of("1234567890-+",end);
		end = s.std::string::find_first_of(" \t\n",start);
		token = s.substr(start, end - start);
		if(check=='b') Ar(k-1)=std::atof(token.c_str());
		else Af(k-1)=std::atof(token.c_str());

		start =s.std::string::find_first_of("1234567890-+",end);
		end = s.std::string::find_first_of(" \t\n",start);
		token = s.substr(start, end - start);
		if(check=='b') nr(k-1)=std::atof(token.c_str());
		else nf(k-1)=std::atof(token.c_str());

		start =s.std::string::find_first_of("1234567890-+",end);
		end = s.std::string::find_first_of(" \t\n",start);
		token = s.substr(start, end - start);
		if(check=='b') Ear(k-1)=std::atof(token.c_str());
		else Eaf(k-1)=std::atof(token.c_str());
std::cout<<Af(k-1)<<"\t"<<nf(k-1)<<"\t"<<Eaf(k-1)<<"\t"<<Ar(k-1)<<"\t"<<nr(k-1)<<"\t"<<Ear(k-1)<<"\n";

//to get pressure dependence coefs

	
		if((end)==std::string::npos)		//check if only forward reactions are pressure dependent
		{
			std::getline(fin,s);
			start =s.std::string::find_first_of("1234567890-+",0);
			end = s.std::string::find_first_of(" \t\n",start);
			std::vector<double> Pcof;
			Pcof.push_back(k);
			while(start!=std::string::npos) //check this
			{
				token = s.substr(start, end - start);
				Pcof.push_back(std::atof(token.c_str()));
				start =s.std::string::find_first_of("1234567890-+",end);
				end = s.std::string::find_first_of(" \t\n",start);
				P++;
			}
			std::getline(fin,s);
			start =s.std::string::find_first_of("1234567890-+",0);
			end = s.std::string::find_first_of(" \t\n",start);
			while(start!=std::string::npos) //check this
			{
				token = s.substr(start, end - start);
				Pcof.push_back(std::atof(token.c_str()));
				start =s.std::string::find_first_of("1234567890-+",end);
				end = s.std::string::find_first_of(" \t\n",start);
				P++;
			}
std::cout<<"for:"<<k<<check<<"\n";
for(int l=0;l<10;++l) std::cout<<Pcof[l]<<"\t";
std::cout<<"\n";
Press_coefs.push_back(Pcof);
for(int l=0;l<10;++l) std::cout<<Press_coefs[0][l]<<"\t";
		}
		std::cout<<"\n";
	}
std::cout<<"done!\n";
	fin.close();
	thirdbodies();
	//to find each atoms MW
//	std::ifstream fin;
	fin.open("MolarMasses.txt", std::ios::in);
	Eigen::VectorXd AMW(A);
	AMW=Eigen::VectorXd::Zero(A);
	for(unsigned i=0;i<A;++i)
	{
		std::string token;
		std::string s=Atoms[i];
		while(fin)
		{
			fin>>token;
			fin>>token;
			for (auto & c: token) c = toupper(c);
			if(token==s)
			{
				fin>>token;
				fin>>token;
				AMW(i)=std::atof(token.c_str());
				break;
			}
		}
std::cout<<AMW(i)<<"\t";
	}
std::cout<<"^atom's MM\n";

/*Te different molecules
NC7KET35-C7H14O3 - first part not counted
C7H14OOH3-5O2-C7H15O4 ?
C7H14OOH3-5-C7H15O2
N-C7H16 N not counted
P-C4H9

*/
	//to assign MW to each Spc
	std::string ch1="";
	std::string ch2="";
	std::string num="";
	int n=0;
	unsigned j=0;
	MW.resize(N);
	MW=Eigen::VectorXd::Zero(N);
	for(unsigned i=0;i<N;++i)
	{
		ch1="";
		ch2="";
		num="";
		n=0;
		j=0;

std::cout<<Species[i]<<"\t";
		if(Species[i].find_last_of("-")!=std::string::npos)
			j=Species[i].find_last_of("-")+1;
		while(j<Species[i].length()) 
		{
			if(isalpha(Species[i][j]))
			{
				num="";
				ch1=ch2=Species[i][j];
				if(j<Species[i].length()-1)
					ch2+=Species[i][++j];
				int c1=get_Index(ch1,Atoms);
				int c2=get_Index(ch2,Atoms);
				if(c1!=-1||c2!=-1)
				{
					if(c1!=-1&&c2==-1)
						c2=c1;
					else
						j++;
					
					while(j<Species[i].length()&&isdigit(Species[i][j]))
						{num+=Species[i][j];j++;}
					if(num=="")
						n=1;
					else
						n=std::atof(num.c_str());
					MW(i)+=(n*AMW(c2));
				}
			}
			else
				j++;
		}
std::cout<<MW(i)<<'\n';
	}
std::cout<<"\nMWs\n";


	return 0;
}
