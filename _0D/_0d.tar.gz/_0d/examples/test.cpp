#include<iostream>
#include<iomanip>
#include<vector>
#include<Eigen/Dense>

#include"anukalana.hpp"

class myIntegrator : public Integrator {
protected:
	Eigen::VectorXd function(double t, Eigen::VectorXd y){
		Eigen::VectorXd temp;
		temp	=	y;
		return temp;
	};

	Eigen::MatrixXd Jacobian(double t, Eigen::VectorXd y){
		Eigen::MatrixXd J	=	Eigen::MatrixXd::Zero(y.rows(),y.rows());
		return J;
	};

public:
	myIntegrator(Eigen::VectorXd yInitial, double tInit, int nTimeSteps, double deltat) : Integrator(yInitial, tInit, nTimeSteps, deltat){};
	~myIntegrator(){};
};

int main(int argc, char* argv[]) {
	int N	=	atoi(argv[1]);
	srand(time(NULL));
	Eigen::VectorXd yInitial	=	Eigen::VectorXd::Ones(N)+Eigen::VectorXd::Random(N);
	double tInit				=	0.0;
	double tFinal				=	10.0;
	double deltat				=	1e-1;
	Eigen::VectorXd yFinalExact;
	yFinalExact					=	yInitial*exp(tFinal);

	Eigen::VectorXd yFinalComputed;
	std::vector<Eigen::VectorXd> yFinalComputedAll;

	std::cout << "\nRelative error in \n" << std::setprecision(16);

	//	Initialize the integrator
	myIntegrator A(yInitial, tInit, tFinal, deltat);

	std::vector<double> parameters;

	//	EulerExplicit
	yFinalComputed		=	A.RK_NonAdaptive(1,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(1,1,parameters);
	std::cout << "\nEuler Explicit solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nEuler Explicit solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK2
	parameters.push_back(0.5);
	yFinalComputed		=	A.RK_NonAdaptive(2,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(2,1,parameters);
	std::cout << "\nRK2 solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK2 solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK3
	parameters.clear();
	parameters.push_back(0.25);
	parameters.push_back(0.75);
	yFinalComputed		=	A.RK_NonAdaptive(3,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(3,1,parameters);
	std::cout << "\nRK3 solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK3 solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK4nonclassical
	parameters.clear();
	parameters.push_back(0.25);
	parameters.push_back(0.5);
	yFinalComputed		=	A.RK_NonAdaptive(4,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(4,1,parameters);
	std::cout << "\nRK4 non-classical solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK4 non-classical solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK4classical
	parameters.clear();
	parameters.push_back(0.5);
	parameters.push_back(0.5);
	yFinalComputed		=	A.RK_NonAdaptive(4,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(4,1,parameters);
	std::cout << "\nRK4 classical solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK4 classical solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK5 method 1
	parameters.clear();
	yFinalComputed		=	A.RK_NonAdaptive(5,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(5,1,parameters);
	std::cout << "\nRK5 solution using method 1 is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK5 solution using method 1 is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK5 method 2
	parameters.clear();
	yFinalComputed		=	A.RK_NonAdaptive(5,2,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(5,2,parameters);
	std::cout << "\nRK5 solution using method 2 is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK5 solution using method 2 is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	RK6
	parameters.clear();
	parameters.push_back(1.0/3.0);
	parameters.push_back(4.0);
	yFinalComputed		=	A.RK_NonAdaptive(6,1,parameters);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(6,1,parameters);
	std::cout << "\nRK6 solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK6 solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	AdamsBashforth
	yFinalComputed		=	A.AdamsBashforth_NonAdaptive();
	yFinalComputedAll	=	A.AdamsBashforth_NonAdaptive_All();
	std::cout << "\nAdams Bashforth solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nAdams Bashforth solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	LeapFrog
	yFinalComputed		=	A.LeapFrog_NonAdaptive();
	yFinalComputedAll	=	A.LeapFrog_NonAdaptive_All();
	std::cout << "\nCentral Difference solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nCentral Difference solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	//	EulerImplicit
	yFinalComputed		=	A.EulerImplicit_NonAdaptive();
	yFinalComputedAll	=	A.EulerImplicit_NonAdaptive_All();
	std::cout << "\nEuler Implicit solution is: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nEuler Implicit solution is: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";

	double tolerance	=	1e-6;
	std::vector<double> timesteps;

	// RK21 Adaptive
	tolerance	=	1e-6;
	parameters.clear();
	timesteps.clear();
	yFinalComputed		=	A.RK_Adaptive(2, 1, parameters, tolerance);
	yFinalComputedAll	=	A.RK_Adaptive_All(2, 1, parameters, tolerance, timesteps);
	std::cout << "\nRK Adaptive time stepping for 21: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK Adaptive time stepping for 21: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nNumber of steps taken by adaptive RK 21 is: " << yFinalComputedAll.size() << "\n";

	//	RK32 Adaptive
	tolerance	=	1e-6;
	parameters.clear();
	timesteps.clear();
	yFinalComputed		=	A.RK_Adaptive(3, 1, parameters, tolerance);
	yFinalComputedAll	=	A.RK_Adaptive_All(3, 1, parameters, tolerance, timesteps);
	std::cout << "\nRK Adaptive time stepping for 32: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK Adaptive time stepping for 32: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nNumber of steps taken by adaptive RK4 32 is: " << yFinalComputedAll.size() << "\n";

	//	RK54 method 1 Adaptive
	tolerance	=	1e-6;
	parameters.clear();
	timesteps.clear();
	yFinalComputed		=	A.RK_Adaptive(5, 1, parameters, tolerance);
	yFinalComputedAll	=	A.RK_Adaptive_All(5, 1, parameters, tolerance, timesteps);
	std::cout << "\nRK Adaptive time stepping for 541: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK Adaptive time stepping for 541: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nNumber of steps taken by adaptive RK 541 is: " << yFinalComputedAll.size() << "\n";

	//	RK54 method 2 Adaptive
	tolerance	=	1e-6;
	parameters.clear();
	timesteps.clear();
	yFinalComputed		=	A.RK_Adaptive(5, 2, parameters, tolerance);
	yFinalComputedAll	=	A.RK_Adaptive_All(5, 2, parameters, tolerance, timesteps);
	std::cout << "\nRK Adaptive time stepping for 542: " << (yFinalComputed - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nRK Adaptive time stepping for 542: " << (yFinalComputedAll.back() - yFinalExact).norm()/yFinalExact.norm() << "\n";
	std::cout << "\nNumber of steps taken by adaptive RK 542 is: " << yFinalComputedAll.size() << "\n";
}
