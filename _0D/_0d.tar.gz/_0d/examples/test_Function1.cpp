#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<vector>
#include<Eigen/Dense>

#include"anukalana.hpp"
#include"FUNCTION1.HPP"

double tInit				=	0.0;
double tFinal				=	1000;
long unsigned nTimeSteps;
double deltat;


class myIntegrator: public Integrator,public Isobaric
{
	protected:
	Eigen::VectorXd function(double t, Eigen::VectorXd y)
	{
		Eigen::VectorXd temp(y.rows());
		for(unsigned i=0;i<N;i++)
		{
			temp(i)=XiODE(y(N),y,t,i);
		}
		temp(N)	=TempODE(y(N),y,t); 
		
		return temp;
	};


	public:
	myIntegrator(Eigen::VectorXd yInitial, double tInit, int nTimeSteps, double deltat,double To, Eigen::VectorXd Xi,double Q, double m) : Integrator(yInitial, tInit, nTimeSteps, deltat),Isobaric(To,Xi,Q,m){};
	~myIntegrator(){};
};

void writeToFile(std::string fileName, std::vector<Eigen::VectorXd> yFinalComputedAll, unsigned No) 
{
	std::ofstream myfile;
	myfile.open(fileName.c_str(),std::ios::out);
	myfile << "\\addplot[mark = o,red] coordinates {";
	for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) 
	{
		myfile << "(" << tInit+j*deltat ;
		for(unsigned k=0;k<No;++k)
			myfile  << ","<< yFinalComputedAll[j](k);
		myfile << ")";
	}
	myfile << "};\n";
	// myfile << "\\addplot[mark = o,blue] coordinates {";
	// for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
	// 	myfile << "(" << tInit+j*deltat << "," << yFinalComputedAll[j](1) << ")";
	// }
	// myfile << "};\n";
	myfile.close();
}

void writeToFile(std::string fileName, std::vector<double>& timesteps, std::vector<Eigen::VectorXd> yFinalComputedAll,unsigned No) 
{
	std::ofstream myfile;
	myfile.open(fileName.c_str(),std::ios::out);
	myfile << "\\addplot[mark = o,red] coordinates {";
	long unsigned int nTimeSteps	=	timesteps.size();
	for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) 
	{
		myfile << "(" << timesteps[j];
		for(unsigned k=0;k<No;++k)
			myfile  << ","<< yFinalComputedAll[j](k);
		myfile << ")";
	}
	myfile << "};\n";
	// myfile << "\\addplot[mark = o,blue] coordinates {";
	// for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
	// 	myfile << "(" << timesteps[j] << "," << yFinalComputedAll[j](1) << ")";
	// }
	// myfile << "};\n";
	myfile.close();
}

int main(int argc, char* argv[]) 
{
	nTimeSteps	=	double(atoi(argv[1]));
	deltat		=	double(tFinal-tInit)/double(nTimeSteps);
	int No	=	5;
	srand(time(NULL));

	double To=301.0; //random
	Eigen::VectorXd Xi(33);
	for(unsigned i=0;i<33;++i) Xi(i)=1; //random
	double Q=3000.0;//random
	double m=100.0;	//random
	Eigen::VectorXd yInitial(No);
	yInitial = Xi;
	yInitial.resize(No);
	yInitial(No-1)=To;

	myIntegrator A(yInitial,tInit, nTimeSteps, deltat, To,Xi,Q,m);
/*
	std::vector<Eigen::VectorXd> yFinalComputedAll;

	std::ofstream myfile;
	std::string fileName;

	//	EulerExplicit or RK1
	std::vector<double> parameters;
	yFinalComputedAll	=	A.RK_NonAdaptive_All(1,1,parameters);
	fileName			=	"./output_Function1/Isobaric_EulerExplicit_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll,No);

	//	RK2
	parameters.clear();
	parameters.push_back(0.5);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(2,1,parameters);
	fileName			=	"./output_Function1/Isobaric_RK2stage_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll,No);

*/	
	
	return 0;
	
}
