#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<vector>
#include<Eigen/Dense>

#include"anukalana.hpp"


double tInit				=	0.0;
double tFinal				=	1000;
long unsigned nTimeSteps;
double deltat;

class myIntegrator : public Integrator {
protected:
	Eigen::VectorXd function(double t, Eigen::VectorXd y){
		Eigen::VectorXd temp(y.rows());
		temp(0)	=	y(1);
		temp(1)	=	1000.0*(1-y(0)*y(0))*y(1)-y(0);
		return temp;
	};

	Eigen::MatrixXd Jacobian(double t, Eigen::VectorXd y){
		Eigen::MatrixXd J(y.rows(),y.rows());
		J(0,0)	=	0.0;
		J(0,1)	=	1.0;
		J(1,0)	=	-2000.0*y(0)*y(1)-y(0);
		J(1,1)	=	1000.0*(1-y(0)*y(0));
		return J;
	};

public:
	myIntegrator(Eigen::VectorXd yInitial, double tInit, int nTimeSteps, double deltat) : Integrator(yInitial, tInit, nTimeSteps, deltat){};
	~myIntegrator(){};
};

void writeToFile(std::string fileName, std::vector<Eigen::VectorXd> yFinalComputedAll) {
	std::ofstream myfile;
	myfile.open(fileName.c_str(),std::ios::out);
	myfile << "\\addplot[mark = o,red] coordinates {";
	for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
		myfile << "(" << tInit+j*deltat << "," << yFinalComputedAll[j](0) << ")";
	}
	myfile << "};\n";
	// myfile << "\\addplot[mark = o,blue] coordinates {";
	// for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
	// 	myfile << "(" << tInit+j*deltat << "," << yFinalComputedAll[j](1) << ")";
	// }
	// myfile << "};\n";
	myfile.close();
}

void writeToFile(std::string fileName, std::vector<double>& timesteps, std::vector<Eigen::VectorXd> yFinalComputedAll) {
	std::ofstream myfile;
	myfile.open(fileName.c_str(),std::ios::out);
	myfile << "\\addplot[mark = o,red] coordinates {";
	long unsigned int nTimeSteps	=	timesteps.size();
	for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
		myfile << "(" << timesteps[j] << "," << yFinalComputedAll[j](0) << ")";
	}
	myfile << "};\n";
	// myfile << "\\addplot[mark = o,blue] coordinates {";
	// for (unsigned long int j=0; j<nTimeSteps; j+=nTimeSteps/1000) {
	// 	myfile << "(" << timesteps[j] << "," << yFinalComputedAll[j](1) << ")";
	// }
	// myfile << "};\n";
	myfile.close();
}

int main(int argc, char* argv[]) {
	nTimeSteps	=	double(atoi(argv[1]));
	deltat		=	double(tFinal-tInit)/double(nTimeSteps);
	int N	=	2;
	srand(time(NULL));
	Eigen::VectorXd yInitial(N);
	yInitial(0)		=	2.0;
	yInitial(1)		=	0.0;

	std::vector<Eigen::VectorXd> yFinalComputedAll;

	std::ofstream myfile;
	std::string fileName;

	//	Initialize the integrator
	myIntegrator A(yInitial, tInit, tFinal, deltat);

	//	EulerExplicit or RK1
	std::vector<double> parameters;
	yFinalComputedAll	=	A.RK_NonAdaptive_All(1,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/EulerExplicit_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK2
	parameters.clear();
	parameters.push_back(0.5);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(2,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK2stage_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK3
	parameters.clear();
	parameters.push_back(0.25);
	parameters.push_back(0.75);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(3,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK3_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK4nonclassical
	parameters.clear();
	parameters.push_back(0.25);
	parameters.push_back(0.5);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(4,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK4nonclassical_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK4classical
	parameters.clear();
	parameters.push_back(0.5);
	parameters.push_back(0.5);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(4,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK4_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK5 method 1
	parameters.clear();
	yFinalComputedAll	=	A.RK_NonAdaptive_All(5,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK5_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK5 method 2
	parameters.clear();
	yFinalComputedAll	=	A.RK_NonAdaptive_All(5,2,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK5_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	RK6
	parameters.clear();
	parameters.push_back(1.0/3.0);
	parameters.push_back(4.0);
	yFinalComputedAll	=	A.RK_NonAdaptive_All(6,1,parameters);
	fileName			=	"./output_Stiff_Nonlinear/RK6_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	AdamsBashforth
	yFinalComputedAll	=	A.AdamsBashforth_NonAdaptive_All();
	fileName			=	"./output_Stiff_Nonlinear/AdamsBashforth_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	CentralDifference
	yFinalComputedAll	=	A.LeapFrog_NonAdaptive_All();
	fileName			=	"./output_Stiff_Nonlinear/LeapFrog_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	//	EulerImplicit
	yFinalComputedAll	=	A.EulerImplicit_NonAdaptive_All();
	fileName			=	"./output_Stiff_Nonlinear/EulerImplicit_NonAdaptive_All.txt";
	writeToFile(fileName, yFinalComputedAll);

	std::vector<double> timesteps;
	double tolerance	=	1e-6;

	// RK21 Adaptive
	parameters.clear();
	timesteps.clear();
	yFinalComputedAll	=	A.RK_Adaptive_All(2, 1, parameters, tolerance, timesteps);
	fileName			=	"./output_Stiff_Nonlinear/RK2_Adaptive_All.txt";
	writeToFile(fileName, timesteps, yFinalComputedAll);
	std::cout << "\nNumber of timesteps is: " << timesteps.size() << "\n";
	std::cout << "\nDone with RK2_Adaptive_All\n";

	// RK31 Adaptive
	parameters.clear();
	timesteps.clear();
	yFinalComputedAll	=	A.RK_Adaptive_All(3, 1, parameters, tolerance, timesteps);
	fileName			=	"./output_Stiff_Nonlinear/RK3_Adaptive_All.txt";
	writeToFile(fileName, timesteps, yFinalComputedAll);
	std::cout << "\nNumber of timesteps is: " << timesteps.size() << "\n";
	std::cout << "\nDone with RK3_Adaptive_All\n";

	// RK51 Adaptive
	parameters.clear();
	timesteps.clear();
	yFinalComputedAll	=	A.RK_Adaptive_All(5, 1, parameters, tolerance, timesteps);
	fileName			=	"./output_Stiff_Nonlinear/RK51_Adaptive_All.txt";
	writeToFile(fileName, timesteps, yFinalComputedAll);
	std::cout << "\nNumber of timesteps is: " << timesteps.size() << "\n";
	std::cout << "\nDone with RK5_Adaptive_All\n";

	// RK52 Adaptive
	parameters.clear();
	timesteps.clear();
	yFinalComputedAll	=	A.RK_Adaptive_All(5, 2, parameters, tolerance, timesteps);
	fileName			=	"./output_Stiff_Nonlinear/RK52_Adaptive_All.txt";
	writeToFile(fileName, timesteps, yFinalComputedAll);
	std::cout << "\nNumber of timesteps is: " << timesteps.size() << "\n";
	std::cout << "\nDone with RK5_Adaptive_All\n";

	std::cout << "\n";
}
