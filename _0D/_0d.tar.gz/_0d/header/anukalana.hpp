/*!
 *  \copyright This Source Code Form is subject to the terms of the Mozilla Public
 *  License, v. 2.0. If a copy of the MPL was not distributed with this
 *  file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *  \author Sivaram Ambikasaran, Krithika Narayanaswamy
 *  \version 3.1
 */
/*! \file	BBFMM2D.hpp
 header files needed for using BBFMM2D library
*/

#ifndef __ANUKALANA_HPP__
#define __ANUKALANA_HPP__

#include<cmath>
#include<vector>
#include<Eigen/Dense>
#include<iostream>

class Integrator {
protected:
	Eigen::VectorXd yInitial;
	double tInit;
	int nTimeSteps;
	double deltat;
	double tFinal;
	std::string fileName;
	std::vector<Eigen::VectorXd> yAll;

	//	The following variables (a, b, c and ctar) are needed only for RK schemes
	std::vector<double> a;
	std::vector<double> b;
	std::vector<double> c;
	std::vector<double> cstar;

	Integrator(Eigen::VectorXd yInitial, double tInit, double tFinal, double deltat) {
		this->yInitial	=	yInitial;
		this->tInit		=	tInit;
		this->tFinal	=	tFinal;
		this->deltat	=	deltat;
		this->nTimeSteps=	(tFinal-tInit)/deltat;
	};

	virtual Eigen::VectorXd function(double t, Eigen::VectorXd y) {
		return y;
	};

	virtual Eigen::MatrixXd Jacobian(double t, Eigen::VectorXd y) {
		return Eigen::MatrixXd::Zero(y.rows(),y.rows());
	};

	//	Nonadaptive RK schemes
	void RK_NonAdaptive_Driver(double dt, double& t, Eigen::VectorXd& yNext);
	void RK_NonAdaptive_Coefficients(int nOrder, int method, std::vector<double> parameters);

	//	Driver for all Adaptive RK schemes
	void RK_Adaptive_Driver(double dt, double& t, Eigen::VectorXd& yNext, Eigen::VectorXd& error);
	void RK_Adaptive_Coefficients(int nOrder, int method, std::vector<double> parameters);

	//	Adamsbashforth Single step
	void Adamsbashforth_Singlestep(double dt, double& t, Eigen::VectorXd& yPrev, Eigen::VectorXd& yNext);

	//	LeapFrog Single step
	void LeapFrog_Singlestep(double dt, double& t, Eigen::VectorXd& yPrev, Eigen::VectorXd& yNext);

	//	EulerImplicit Single step
	void EulerImplicit_Singlestep(double dt, double& t, Eigen::VectorXd& yNext);
	
public:
	//	RK Explicit
	Eigen::VectorXd RK_NonAdaptive(int nOrder, int method, std::vector<double> parameters);
	std::vector<Eigen::VectorXd> RK_NonAdaptive_All(int nOrder, int method, std::vector<double> parameters);

	//	RK Explicit Adaptive
	Eigen::VectorXd RK_Adaptive(int nOrder, int method, std::vector<double> parameters, double tolerance);
	std::vector<Eigen::VectorXd> RK_Adaptive_All(int nOrder, int method, std::vector<double> parameters, double tolerance, std::vector<double>& timesteps);

	//	Adamsbashforth
	Eigen::VectorXd AdamsBashforth_NonAdaptive();
	std::vector<Eigen::VectorXd> AdamsBashforth_NonAdaptive_All();

	//	LeapFrog
	Eigen::VectorXd LeapFrog_NonAdaptive();
	std::vector<Eigen::VectorXd> LeapFrog_NonAdaptive_All();

	//	Euler Implicit
	Eigen::VectorXd EulerImplicit_NonAdaptive();
	std::vector<Eigen::VectorXd> EulerImplicit_NonAdaptive_All();
	~Integrator(){};
};

#endif //(__ANUKALANA_HPP__)
