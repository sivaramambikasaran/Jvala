# Anukalana
ODE Integrator

---

To run a generic test, proceed as follows.

First clean the directory:

	make -f makefile.mk clean

Make the makefile:

	make -f makefile.mk

Run the code as:

	./exec/test N

where `N` is the number of unknowns (i.e., the size of the vector). For instance,

	./exec/test 10

The function to be integrated can be changed inside the test.cpp file in examples folder.

---

To run a nonlinear test.

First clean the directory:

	make -f makefilenonlinear.mk clean

Make the makefile:

	make -f makefilenonlinear.mk

Run the code as:

	./exec/testnonlinear nTimeSteps

where `nTimeSteps` is the number of timesteps for the problem.

	./exec/test 1200

The function to be integrated can be changed inside the test_nonstiff_nonlinear.cpp file in examples folder.

---

To run a stiff nonlinear test.

First clean the directory:

	make -f makefilestiffnonlinear.mk clean

Make the makefile:

	make -f makefilestiffnonlinear.mk

Run the code as:

	./exec/teststiffnonlinear nTimeSteps

where `nTimeSteps` is the number of timesteps for the problem.

	./exec/test 10000000

The function to be integrated can be changed inside the test_stiff_nonlinear.cpp file in examples folder.
